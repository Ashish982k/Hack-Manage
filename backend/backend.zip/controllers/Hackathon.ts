import { mkdir, writeFile } from "fs/promises";
import path from "path";
import crypto from "crypto";
import { eq } from "drizzle-orm";
import { db } from "../src/db";
import {
  hackathons,
  problemStatements,
  submissions,
  teamMembers,
  stages,
  teams,
  user,
} from "../src/db/schema";
import type { Context } from "hono";

type ProblemStatementInput =
  | string
  | {
      title?: string;
      description?: string;
      body?: string;
    };

export const upload = async (c: Context) => {
  try {
    const hackathonId = c.req.param("id");
    const user = c.get("user");

    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const userId = user.id;
    const teamMember = await db.query.teamMembers.findFirst({
      where: eq(teamMembers.userId, userId),
      with: {
        team: true,
      },
    });

    if (!teamMember) {
      return c.json({ message: "User is not in any team" }, 400);
    }

    if (teamMember.team.hackathonId !== hackathonId) {
      return c.json(
        { message: "User is not in a team for this hackathon" },
        400,
      );
    }

    const teamId = teamMember.team.id;

    const members = await db.query.teamMembers.findMany({
      where: eq(teamMembers.teamId, teamId),
    });
    const availableProblemStatements =
      await db.query.problemStatements.findMany({
        where: eq(problemStatements.hackathonId, hackathonId),
      });

    const { driveUrl, githubUrl, problemStatementId } = await c.req.json();

    if (!driveUrl) {
      return c.json({ message: "Drive URL is required" }, 400);
    }

    if (availableProblemStatements.length > 0) {
      if (!problemStatementId) {
        return c.json({ message: "Problem statement is required" }, 400);
      }

      const selectedProblemStatement = availableProblemStatements.find(
        (statement) => statement.id === problemStatementId,
      );

      if (!selectedProblemStatement) {
        return c.json({ message: "Invalid problem statement" }, 400);
      }
    }

    const existingSubmission = await db.query.submissions.findFirst({
      where: eq(submissions.teamId, teamId),
    });

    if (existingSubmission) {
      await db
        .update(submissions)
        .set({
          pptUrl: driveUrl,
          githubUrl,
          problemStatementId,
        })
        .where(eq(submissions.id, existingSubmission.id));
    } else {
      await db.insert(submissions).values({
        id: crypto.randomUUID(),
        teamId,
        round: 1,
        pptUrl: driveUrl,
        githubUrl,
        problemStatementId,
      });
    }

    return c.json({
      message: "Submission successful",
      driveUrl,
    });
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const newHackathon = async (c: Context) => {
  try {
    const data = await c.req.parseBody();
    const file = data.headerImage;

    if (
      !data.title ||
      !data.startDate ||
      !data.endDate ||
      !data.registrationDeadline
    ) {
      return c.json(
        {
          message:
            "Title, start date, end date, and registration deadline are required",
        },
        400,
      );
    }

    const safeTitle = (data.title as string)
      .toLowerCase()
      .replace(/\s+/g, "-")
      .replace(/[^a-z0-9-]/g, "");

    let filePath: string | undefined;

    if (file && file instanceof File) {
      const ext = file.name.split(".").pop();
      const fileName = `${Date.now()}-${safeTitle}.${ext}`;
      filePath = path.join("images", fileName);

      await mkdir(path.dirname(filePath), { recursive: true });
      const buffer = Buffer.from(await file.arrayBuffer());
      await writeFile(filePath, buffer);
    }

    const hackathonId = crypto.randomUUID();
    await db.insert(hackathons).values({
      id: hackathonId,
      title: data.title as string,
      description: data.description as string,
      headerImage: filePath ?? null,
      startDate: data.startDate as string,
      endDate: data.endDate as string,
      registrationDeadline: data.registrationDeadline as string,
      location: data.location as string,
      createdBy: c.get("user").id as string,
    });
    const parsedStages = JSON.parse((data.stages as string) || "[]") as Array<{
      title: string;
      description: string;
      startDate: string;
      endDate: string;
    }>;
    const parsedProblemStatements = JSON.parse(
      (data.problemStatements as string) || "[]",
    ) as ProblemStatementInput[];

    for (const stage of parsedStages) {
      await db.insert(stages).values({
        id: crypto.randomUUID(),
        hackathonId,
        title: stage.title,
        description: stage.description,
        startTime: stage.startDate,
        endTime: stage.endDate,
      });
    }

    for (const statement of parsedProblemStatements) {
      const normalizedStatement =
        typeof statement === "string"
          ? {
              title: statement,
              description: "",
            }
          : {
              title: statement.title ?? "",
              description: statement.description ?? statement.body ?? "",
            };

      const trimmedTitle = normalizedStatement.title.trim();
      const trimmedDescription = normalizedStatement.description.trim();

      if (!trimmedTitle) continue;

      await db.insert(problemStatements).values({
        id: crypto.randomUUID(),
        hackathonId,
        title: trimmedTitle,
        description: trimmedDescription || undefined,
      });
    }

    return c.json({
      message: "Hackathon created successfully",
      filePath,
    });
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const getMember = async (c: Context) => {
  try {
    const hackathonId = c.req.param("id");
    const user = c.get("user");

    if (!user) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    const userId = user.id;

    // Find user's team for this hackathon
    const memberships = await db.query.teamMembers.findMany({
      where: eq(teamMembers.userId, userId),
      with: {
        team: true,
      },
    });

    const teamMember = memberships.find(
      (m) => m.team.hackathonId === hackathonId,
    );

    // If user not in any team → return 404
    if (!teamMember) {
      return c.json({ message: "Not part of any team" }, 404);
    }

    // If team exists → return team data
    const members = await db.query.teamMembers.findMany({
      where: eq(teamMembers.teamId, teamMember.team.id),
      with: {
        user: true,
      },
    });

    const submission = await db.query.submissions.findFirst({
      where: eq(submissions.teamId, teamMember.team.id),
    });

    return c.json({
      teamId: teamMember.team.id,
      name: teamMember.team.name,
      leaderId: teamMember.team.leaderId,
      members,
      submission: submission || null,
    });
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const createTeam = async (c: Context) => {
  try {
    const { hackathonId, teamName, members } = await c.req.json();
    const userId = c.get("user").id;

    if (!hackathonId || !teamName) {
      return c.json({ message: "Missing fields" }, 400);
    }

    const hackathon = await db.query.hackathons.findFirst({
      where: eq(hackathons.id, hackathonId),
    });

    if (!hackathon) {
      return c.json({ message: "Invalid Hackathon" }, 400);
    }

    const existingTeam = await db.query.teamMembers.findMany({
      where: eq(teamMembers.userId, userId),
      with: { team: true },
    });

    const already = existingTeam.some(
      (m) => m.team.hackathonId === hackathonId,
    );

    if (already) {
      return c.json({ message: "Already in a team for this hackathon" }, 400);
    }

    const teamId = crypto.randomUUID();

    await db.insert(teams).values({
      id: teamId,
      hackathonId,
      name: teamName,
      leaderId: userId,
    });

    // Add team leader to teamMembers with approved status
    await db.insert(teamMembers).values({
      id: crypto.randomUUID(),
      teamId,
      userId,
      status: "approved",
    });

    // Add other team members
    if (members && Array.isArray(members)) {
      for (const email of members) {
        const foundUser = await db.query.user.findFirst({
          where: eq(user.email, email),
        });

        if (!foundUser) {
          return c.json(
            {
              message: `User with email ${email} is not registered or verified`,
            },
            400,
          );
        }

        if (foundUser.id === userId) continue;

        await db.insert(teamMembers).values({
          id: crypto.randomUUID(),
          teamId,
          userId: foundUser.id,
          status: "pending",
        });
      }
    }

    return c.json({
      message: "Team created successfully",
      teamId,
    });
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const joinHackathon = async (c: Context) => {
  try {
    const userId = c.get("user").id;
    const hackathonId = c.req.param("id");

    // Check if user is already part of a team for this hackathon
    const existingMemberships = await db.query.teamMembers.findMany({
      where: eq(teamMembers.userId, userId),
      with: {
        team: true,
      },
    });

    const alreadyInTeam = existingMemberships.find(
      (m) => m.team.hackathonId === hackathonId,
    );

    if (alreadyInTeam) {
      return c.json({ message: "Already joined this hackathon" }, 409);
    }
    if (!hackathonId) {
      return c.json({ message: "Hackathon not found" }, 404);
    }
    // Validate hackathon exists
    const hackathon = await db.query.hackathons.findFirst({
      where: eq(hackathons.id, hackathonId),
    });

    if (!hackathon) {
      return c.json({ message: "Hackathon not found" }, 404);
    }

    // User can proceed to create team - return success to trigger redirect
    return c.json(
      {
        message: "Ready to create team",
        redirect: true,
      },
      200,
    );
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const deleteUser = async (c: Context) => {
  try {
    const hackathonId = c.req.param("id");
    const userId = c.get("user").id;

    // Find user's team for this hackathon
    const memberships = await db.query.teamMembers.findMany({
      where: eq(teamMembers.userId, userId),
      with: {
        team: true,
      },
    });

    const member = memberships.find((m) => m.team.hackathonId === hackathonId);

    if (!member) {
      return c.json(
        { message: "Not part of any team for this hackathon" },
        404,
      );
    }

    // If user is leader, delete the team (cascade deletes submissions)
    if (member.team.leaderId === userId) {
      await db.delete(teams).where(eq(teams.id, member.team.id));
    } else {
      // Otherwise, just remove user from teamMembers
      await db.delete(teamMembers).where(eq(teamMembers.id, member.id));
    }

    return c.json({ message: "Successfully left hackathon" }, 200);
  } catch (error) {
    console.error(error);
    return c.json({ message: "Something went wrong" }, 500);
  }
};
