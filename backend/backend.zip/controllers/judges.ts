import crypto from "crypto";
import {
  hackathonRoles,
  teams,
  submissions,
  stages,
  evaluations,
  shortlistedTeams,
} from "../src/db/schema";
import { eq, and, inArray, sql, desc, isNotNull, asc } from "drizzle-orm";
import { db } from "../src/db";
import type { Context } from "hono";

export const getSubmissions = async (c: Context) => {
  try {
    const currentUser = c.get("user");
    const hackathonId = c.req.param("id");
    const stageId = c.req.query("stageId")?.trim();

    if (!currentUser?.id) {
      return c.json({ message: "Unauthorized" }, 401);
    }

    if (!hackathonId) {
      return c.json({ message: "Hackathon ID is required" }, 400);
    }

    if (!stageId) {
      return c.json({ message: "Stage ID is required" }, 400);
    }

    const userId = currentUser.id;

    const role = await db.query.hackathonRoles.findFirst({
      where: and(
        eq(hackathonRoles.hackathonId, hackathonId),
        eq(hackathonRoles.userId, userId),
      ),
    });

    if (!role || role.role !== "judge") {
      return c.json({ message: "Unauthorized" }, 403);
    }

    const requestedStage = await db.query.stages.findFirst({
      where: and(
        eq(stages.id, stageId),
        eq(stages.hackathonId, hackathonId),
      ),
    });

    if (!requestedStage) {
      return c.json({ message: "Stage not found for this hackathon" }, 404);
    }

    const readSubmissionsByStage = async (submissionStageId: string) =>
      db
        .select({
          submissionId: submissions.id,
          pptUrl: submissions.pptUrl,
          githubUrl: submissions.githubUrl,
          submittedAt: submissions.submittedAt,

          stageId: stages.id,
          stageTitle: stages.title,
          stageType: stages.type,

          teamId: teams.id,
          teamName: teams.name,
        })
        .from(submissions)
        .innerJoin(teams, eq(submissions.teamId, teams.id))
        .innerJoin(stages, eq(submissions.stageId, stages.id))
        .where(
          and(
            eq(teams.hackathonId, hackathonId),
            eq(submissions.stageId, submissionStageId),
          ),
        );

    let submissionStage = requestedStage;
    if (requestedStage.type !== "SUBMISSION") {
      const latestSubmissionStage = await db.query.stages.findFirst({
        where: and(
          eq(stages.hackathonId, hackathonId),
          eq(stages.type, "SUBMISSION"),
          isNotNull(stages.startTime),
        ),
        orderBy: [desc(sql`datetime(${stages.startTime})`), desc(stages.id)],
      });

      if (latestSubmissionStage) {
        submissionStage = latestSubmissionStage;
      }
    }

    let data = await readSubmissionsByStage(submissionStage.id);

    if (data.length === 0 && requestedStage.type !== "SUBMISSION") {
      const latestSubmittedStage = await db
        .select({ stageId: submissions.stageId })
        .from(submissions)
        .innerJoin(teams, eq(submissions.teamId, teams.id))
        .where(eq(teams.hackathonId, hackathonId))
        .orderBy(desc(submissions.submittedAt))
        .limit(1);

      const fallbackStageId = latestSubmittedStage[0]?.stageId;
      if (fallbackStageId && fallbackStageId !== submissionStage.id) {
        const fallbackStage = await db.query.stages.findFirst({
          where: and(
            eq(stages.id, fallbackStageId),
            eq(stages.hackathonId, hackathonId),
          ),
        });

        if (fallbackStage) {
          submissionStage = fallbackStage;
          data = await readSubmissionsByStage(submissionStage.id);
        }
      }
    }

    const submissionIds = data.map((item) => item.submissionId);
    const evaluatedSubmissionIds =
      submissionIds.length === 0
        ? new Set<string>()
        : new Set(
            (
              await db
                .select({ submissionId: evaluations.submissionId })
                .from(evaluations)
                .where(
                  and(
                    eq(evaluations.judgeId, userId),
                    inArray(evaluations.submissionId, submissionIds),
                  ),
                )
            ).map((item) => item.submissionId),
          );

    const dataWithEvaluationStatus = data.map((item) => ({
      ...item,
      evaluated: evaluatedSubmissionIds.has(item.submissionId),
    }));

    return c.json({
      message: "Submissions fetched successfully",
      submissionStage: {
        id: submissionStage.id,
        title: submissionStage.title,
        type: submissionStage.type,
      },
      count: dataWithEvaluationStatus.length,
      data: dataWithEvaluationStatus,
    });
  } catch (err) {
    console.error(err);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const evaluateSubmission = async (c: Context) => {
  try {
    const hackathonId = c.req.param("id");
    const teamId = c.req.param("teamId");
    const stageId = c.req.query("stageId")?.trim();
    const userId = c.get("user").id;

    if (!userId || !hackathonId || !teamId) {
      return c.json({ message: "Missing required fields" }, 400);
    }

    if (!stageId) {
      return c.json({ message: "Stage ID is required" }, 400);
    }

    const role = await db.query.hackathonRoles.findFirst({
      where: and(
        eq(hackathonRoles.hackathonId, hackathonId),
        eq(hackathonRoles.userId, userId),
      ),
    });

    if (!role || role.role !== "judge") {
      return c.json({ message: "Unauthorized" }, 403);
    }

    const stage = await db.query.stages.findFirst({
      where: and(
        eq(stages.id, stageId),
        eq(stages.hackathonId, hackathonId),
      ),
    });

    if (!stage) {
      return c.json({ message: "Stage not found for this hackathon" }, 404);
    }

    const submitted = await db.query.submissions.findFirst({
      where: and(
        eq(submissions.teamId, teamId),
        eq(submissions.stageId, stageId),
      ),
    });

    if (!submitted) {
      return c.json({ message: "No submission found for this team" }, 400);
    }

    const alreadyEvaluated = await db.query.evaluations.findFirst({
      where: and(
        eq(evaluations.submissionId, submitted.id),
        eq(evaluations.judgeId, userId),
      ),
    });

    const data = await c.req.formData();

    const innovation = Number(data.get("innovation"));
    const feasibility = Number(data.get("feasibility"));
    const technical = Number(data.get("technical"));
    const impact = Number(data.get("impact"));
    const presentation = Number(data.get("presentation"));

    const scores = [innovation, feasibility, technical, impact, presentation];

    const hasInvalidScore = scores.some(
      (score) =>
        !Number.isFinite(score) ||
        !Number.isInteger(score) ||
        score < 0 ||
        score > 10,
    );

    if (hasInvalidScore) {
      return c.json(
        { message: "Scores must be integers between 0 and 10" },
        400,
      );
    }

    const total = innovation + feasibility + technical + impact + presentation;

    if (alreadyEvaluated) {
      await db
        .update(evaluations)
        .set({
          innovation,
          feasibility,
          technical,
          impact,
          presentation,
          total,
        })
        .where(eq(evaluations.id, alreadyEvaluated.id));

      return c.json({
        message: "Evaluation updated successfully",
        total,
      });
    }

    await db.insert(evaluations).values({
      id: crypto.randomUUID(),
      submissionId: submitted.id,
      judgeId: userId,
      innovation,
      feasibility,
      technical,
      impact,
      presentation,
      total,
    });

    return c.json({
      message: "Evaluation submitted successfully",
      total,
    });
  } catch (err) {
    console.error(err);
    return c.json({ message: "Something went wrong" }, 500);
  }
};

export const fetchEvaluatedTeams = async (c: Context) => {
  const hackathonId = c.req.param("id");
  const stageId = c.req.query("stageId")?.trim();
  const userId = c.get("user")?.id;

  if (!userId || !hackathonId) {
    return c.json({ message: "Missing required fields" }, 400);
  }

  if (!stageId) {
    return c.json({ message: "Stage ID is required" }, 400);
  }

  const requestedStage = await db.query.stages.findFirst({
    where: and(
      eq(stages.id, stageId),
      eq(stages.hackathonId, hackathonId),
    ),
  });

  if (!requestedStage) {
    return c.json({ message: "Stage not found for this hackathon" }, 404);
  }

  const leaderboard = await db
    .select({
      teamId: teams.id,
      teamName: teams.name,
      totalScore: sql<number>`AVG(${evaluations.total})`,
      technical: sql<number>`AVG(${evaluations.technical})`,
      innovation: sql<number>`AVG(${evaluations.innovation})`,
      feasibility: sql<number>`AVG(${evaluations.feasibility})`,
      presentation: sql<number>`AVG(${evaluations.presentation})`,
      impact: sql<number>`AVG(${evaluations.impact})`,
      evaluationCount: sql<number>`COUNT(${evaluations.id})`,
    })
    .from(submissions)
    .innerJoin(teams, eq(submissions.teamId, teams.id))
    .innerJoin(evaluations, eq(submissions.id, evaluations.submissionId))
    .where(
      and(
        eq(submissions.stageId, stageId),
        eq(teams.hackathonId, hackathonId),
      ),
    )
    .groupBy(teams.id)
    .orderBy(desc(sql`AVG(${evaluations.total})`));

  return c.json({ stageId: requestedStage.id, data: leaderboard });
};

export const createShortlistedTeams = async (c: Context) => {
  const payload: unknown = await c.req.json().catch(() => null);
  const stageId =
    typeof payload === "object" &&
    payload !== null &&
    "stageId" in payload &&
    typeof (payload as { stageId?: unknown }).stageId === "string"
      ? (payload as { stageId: string }).stageId.trim()
      : "";
  const teamIds =
    typeof payload === "object" &&
    payload !== null &&
    "teamIds" in payload &&
    Array.isArray((payload as { teamIds?: unknown }).teamIds)
      ? (payload as { teamIds: unknown[] }).teamIds
      : null;

  if (!stageId) {
    return c.json({ message: "Stage ID is required" }, 400);
  }

  if (!Array.isArray(teamIds) || teamIds.some((id) => typeof id !== "string")) {
    return c.json({ message: "Invalid teamIds format" }, 400);
  }
  const parsedTeamIds = teamIds as string[];
  const userId = c.get("user")?.id;

  if (!userId) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  const hackathonId = c.req.param("id");
  if (!hackathonId) {
    return c.json({ message: "Hackathon ID is required" }, 400);
  }

  const role = await db.query.hackathonRoles.findFirst({
    where: and(
      eq(hackathonRoles.hackathonId, hackathonId),
      eq(hackathonRoles.userId, userId),
      inArray(hackathonRoles.role, ["judge", "admin"]),
    ),
  });

  if (!role) {
    return c.json({ message: "Unauthorized" }, 403);
  }

  const currentStage = await db.query.stages.findFirst({
    where: and(
      eq(stages.id, stageId),
      eq(stages.hackathonId, hackathonId),
    ),
  });

  if (!currentStage) {
    return c.json({ message: "Stage not found for this hackathon" }, 404);
  }

  const orderedStages = await db.query.stages.findMany({
    where: and(
      eq(stages.hackathonId, hackathonId),
      isNotNull(stages.startTime),
    ),
    orderBy: [asc(sql`datetime(${stages.startTime})`), asc(stages.id)],
  });

  const activeStageIndex = orderedStages.findIndex(
    (stage) => stage.id === currentStage.id,
  );

  const nextStage =
    activeStageIndex >= 0 && activeStageIndex < orderedStages.length - 1
      ? orderedStages[activeStageIndex + 1]
      : null;

  if (!nextStage) {
    return c.json({ message: "No next stage available for shortlisting" }, 400);
  }

  const dedupedTeamIds = Array.from(new Set(parsedTeamIds));
  const validTeams =
    dedupedTeamIds.length === 0
      ? []
      : await db.query.teams.findMany({
          where: and(
            eq(teams.hackathonId, hackathonId),
            inArray(teams.id, dedupedTeamIds),
          ),
          columns: { id: true },
        });

  const validTeamIds = new Set(validTeams.map((team) => team.id));
  if (dedupedTeamIds.some((teamId) => !validTeamIds.has(teamId))) {
    return c.json({ message: "One or more team IDs are invalid" }, 400);
  }

  await db
    .delete(shortlistedTeams)
    .where(
      and(
        eq(shortlistedTeams.hackathonId, hackathonId),
        eq(shortlistedTeams.stageId, nextStage.id),
      ),
    );

  for (const tid of dedupedTeamIds) {
    await db.insert(shortlistedTeams).values({
      id: crypto.randomUUID(),
      teamId: tid,
      hackathonId,
      stageId: nextStage.id,
    });
  }

  return c.json(
    { message: "Teams shortlisted successfully", nextStageId: nextStage.id },
    200,
  );
};

export const fetchShortlistedTeams = async (c: Context) => {
  const hackathonId = c.req.param("id");
  const stageId = c.req.query("stageId")?.trim();
  const userId = c.get("user")?.id;

  if (!userId) {
    return c.json({ message: "Unauthorized" }, 401);
  }

  if (!hackathonId) {
    return c.json({ message: "Hackathon ID is required" }, 400);
  }

  if (!stageId) {
    return c.json({ message: "Stage ID is required" }, 400);
  }

  const requestedStage = await db.query.stages.findFirst({
    where: and(
      eq(stages.id, stageId),
      eq(stages.hackathonId, hackathonId),
    ),
  });

  if (!requestedStage) {
    return c.json({ message: "Stage not found for this hackathon" }, 404);
  }

  const shortlistedRows = await db
    .select({
      id: shortlistedTeams.id,
      teamId: shortlistedTeams.teamId,
      teamName: teams.name,
    })
    .from(shortlistedTeams)
    .innerJoin(teams, eq(shortlistedTeams.teamId, teams.id))
    .where(
      and(
        eq(shortlistedTeams.hackathonId, hackathonId),
        eq(shortlistedTeams.stageId, stageId),
      ),
    )
    .orderBy(teams.name);

  return c.json({ stageId, data: shortlistedRows });
};

