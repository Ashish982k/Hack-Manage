import { createAuthClient } from "better-auth/react";
import { buildApiUrl } from "@/api/client";

export const authClient = createAuthClient({
  baseURL: buildApiUrl("/api/auth"),
});
