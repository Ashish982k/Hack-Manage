import { fetchFromApi } from "./client";

export const scanQrCode = (payload: { qrData: string; hackathonId?: string }) =>
  fetchFromApi("/qr/scan", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      qrData: payload.qrData,
      token: payload.qrData,
      hackathonId: payload.hackathonId,
    }),
  });
