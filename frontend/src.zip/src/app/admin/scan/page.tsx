"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ShieldCheck } from "lucide-react";

import { Navbar } from "@/components/navbar";
import { QrScannerCard } from "@/components/qr/qr-scanner-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { authClient } from "@/lib/auth-client";
import { scanQrCode } from "@/api";

type ScanFeedback = {
  kind: "success" | "error";
  message: string;
  payload: unknown;
};

const readMessage = (value: unknown) => {
  if (
    typeof value === "object" &&
    value !== null &&
    "message" in value &&
    typeof (value as { message?: unknown }).message === "string"
  ) {
    return (value as { message: string }).message;
  }

  return null;
};

const readScanPayload = (value: unknown): Record<string, unknown> | null => {
  if (typeof value !== "object" || value === null) return null;

  if (
    "data" in value &&
    typeof (value as { data?: unknown }).data === "object" &&
    (value as { data?: unknown }).data !== null
  ) {
    return (value as { data: Record<string, unknown> }).data;
  }

  return value as Record<string, unknown>;
};

const readBoolean = (value: unknown, key: string): boolean | null =>
  typeof value === "object" &&
  value !== null &&
  key in value &&
  typeof (value as Record<string, unknown>)[key] === "boolean"
    ? ((value as Record<string, unknown>)[key] as boolean)
    : null;

const readString = (value: unknown, key: string): string | null =>
  typeof value === "object" &&
  value !== null &&
  key in value &&
  typeof (value as Record<string, unknown>)[key] === "string"
    ? ((value as Record<string, unknown>)[key] as string)
    : null;

export default function AdminScanPage() {
  const router = useRouter();
  const { data: session, isPending: isSessionPending } = authClient.useSession();

  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [feedback, setFeedback] = React.useState<ScanFeedback | null>(null);

  React.useEffect(() => {
    if (isSessionPending) return;
    if (!session?.user?.id) {
      router.push("/login");
    }
  }, [isSessionPending, router, session?.user?.id]);

  const handleScan = React.useCallback(async (qrValue: string) => {
    setIsSubmitting(true);
    setFeedback(null);

    try {
      const res = await scanQrCode({ qrData: qrValue });
      const data: unknown = await res.json().catch(() => null);

      if (!res.ok) {
        setFeedback({
          kind: "error",
          message: readMessage(data) ?? "Scan failed. Please try again.",
          payload: data,
        });
        return;
      }

      setFeedback({
        kind: "success",
        message: readMessage(data) ?? "Scan processed successfully.",
        payload: data,
      });
    } catch {
      setFeedback({
        kind: "error",
        message: "Unable to process scan right now.",
        payload: null,
      });
    } finally {
      setIsSubmitting(false);
    }
  }, []);

  const payload = feedback ? readScanPayload(feedback.payload) : null;
  const isAllowed =
    readBoolean(payload, "allowed") ?? readBoolean(payload, "entryAllowed");
  const isUsed = readBoolean(payload, "isUsed");
  const foodType = readString(payload, "foodType") ?? readString(payload, "type");

  return (
    <div className="relative min-h-screen bg-black text-white">
      <Navbar />

      <div className="mx-auto w-full max-w-4xl px-4 py-12 sm:px-6">
        <button
          onClick={() => router.push("/hackathons")}
          className="mb-8 flex items-center gap-2 text-sm text-white/50 hover:text-white/80"
        >
          <ArrowLeft className="size-4" />
          Back to Hackathons
        </button>

        <Card className="border-white/10 bg-black/20">
          <CardHeader>
            <CardTitle className="inline-flex items-center gap-2 text-white">
              <ShieldCheck className="size-5 text-emerald-300" />
              Admin Scanner
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-white/60">
              Scan participant/team QR for entry and food operations.
            </p>

            <QrScannerCard
              onScan={handleScan}
              isBusy={isSubmitting}
              busyText="Processing scan..."
            />

            {feedback ? (
              <div className="rounded-xl border border-white/10 bg-black/20 p-4">
                <p
                  className={
                    feedback.kind === "success"
                      ? "text-sm text-emerald-300"
                      : "text-sm text-rose-300"
                  }
                >
                  {feedback.message}
                </p>

                {isAllowed !== null ? (
                  <p className="mt-2 text-sm text-white/70">
                    Entry:{" "}
                    <span className={isAllowed ? "text-emerald-300" : "text-rose-300"}>
                      {isAllowed ? "Allowed" : "Denied"}
                    </span>
                  </p>
                ) : null}

                {foodType ? (
                  <p className="mt-1 text-sm text-white/70">
                    Food type: <span className="text-white/90">{foodType}</span>
                  </p>
                ) : null}

                {isUsed !== null ? (
                  <p className="mt-1 text-sm text-white/70">
                    Usage status:{" "}
                    <span className={isUsed ? "text-amber-300" : "text-emerald-300"}>
                      {isUsed ? "Already used" : "Not used"}
                    </span>
                  </p>
                ) : null}

                {payload ? (
                  <pre className="mt-3 overflow-x-auto rounded-md border border-white/10 bg-black/30 p-3 text-xs text-white/70">
                    {JSON.stringify(payload, null, 2)}
                  </pre>
                ) : null}
              </div>
            ) : null}

            <div className="pt-1">
              <Button variant="outline" onClick={() => router.push("/hackathons")}>
                Return to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
