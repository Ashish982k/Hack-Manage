"use client";

import * as React from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft, ScanLine } from "lucide-react";

import { Navbar } from "@/components/navbar";
import { QrScannerCard } from "@/components/qr/qr-scanner-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { authClient } from "@/lib/auth-client";
import { fetchJudgeAccess, scanQrCode } from "@/api";

type StageType = "SUBMISSION" | "EVALUATION" | "FINAL";

const isStageType = (value: unknown): value is StageType =>
  value === "SUBMISSION" || value === "EVALUATION" || value === "FINAL";

const readMessage = (value: unknown) => {
  if (
    typeof value === "object" &&
    value !== null &&
    "message" in value &&
    typeof (value as { message?: unknown }).message === "string"
  ) {
    return (value as { message: string }).message;
  }

  return null;
};

const readAccess = (
  value: unknown,
): { isJudge: boolean; activeStageType: StageType | null } | null => {
  if (
    typeof value !== "object" ||
    value === null ||
    !("isJudge" in value) ||
    typeof (value as { isJudge?: unknown }).isJudge !== "boolean"
  ) {
    return null;
  }

  const stage = "activeStageType" in value
    ? (value as { activeStageType?: unknown }).activeStageType
    : null;

  return {
    isJudge: (value as { isJudge: boolean }).isJudge,
    activeStageType: isStageType(stage) ? stage : null,
  };
};

const readScanResult = (
  value: unknown,
): { teamId: string | null; hackathonId: string | null } => {
  const container =
    typeof value === "object" &&
    value !== null &&
    "data" in value &&
    typeof (value as { data?: unknown }).data === "object" &&
    (value as { data?: unknown }).data !== null
      ? (value as { data: Record<string, unknown> }).data
      : (typeof value === "object" && value !== null
          ? (value as Record<string, unknown>)
          : null);

  if (!container) {
    return { teamId: null, hackathonId: null };
  }

  const teamId =
    typeof container.teamId === "string" ? container.teamId : null;
  const hackathonId =
    typeof container.hackathonId === "string" ? container.hackathonId : null;

  return { teamId, hackathonId };
};

export default function JudgeFinalScannerPage() {
  const router = useRouter();
  const params = useParams<{ id: string | string[] }>();
  const hackathonId = Array.isArray(params.id) ? params.id[0] : params.id;
  const { data: session, isPending: isSessionPending } = authClient.useSession();

  const [isAuthorizing, setIsAuthorizing] = React.useState(true);
  const [canScan, setCanScan] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [feedback, setFeedback] = React.useState<{
    kind: "success" | "error";
    message: string;
  } | null>(null);

  React.useEffect(() => {
    if (isSessionPending) return;

    if (!session?.user?.id) {
      router.push("/login");
      return;
    }

    if (!hackathonId) {
      setCanScan(false);
      setError("Hackathon not found.");
      setIsAuthorizing(false);
      return;
    }

    const verifyAccess = async () => {
      setIsAuthorizing(true);
      setError(null);

      try {
        const res = await fetchJudgeAccess(hackathonId);
        const data: unknown = await res.json().catch(() => null);

        if (!res.ok) {
          setCanScan(false);
          setError(readMessage(data) ?? "Unable to verify access.");
          return;
        }

        const access = readAccess(data);
        if (!access || !access.isJudge) {
          setCanScan(false);
          setError("Only judges can use this scanner.");
          return;
        }

        if (access.activeStageType !== "FINAL") {
          setCanScan(false);
          setError("Scanner is available only during the FINAL stage.");
          return;
        }

        setCanScan(true);
      } catch {
        setCanScan(false);
        setError("Unable to verify access right now.");
      } finally {
        setIsAuthorizing(false);
      }
    };

    void verifyAccess();
  }, [hackathonId, isSessionPending, router, session?.user?.id]);

  const handleScan = React.useCallback(
    async (qrValue: string) => {
      if (!hackathonId) return;

      setIsSubmitting(true);
      setFeedback(null);

      try {
        const res = await scanQrCode({ qrData: qrValue, hackathonId });
        const data: unknown = await res.json().catch(() => null);

        if (!res.ok) {
          setFeedback({
            kind: "error",
            message: readMessage(data) ?? "Unable to validate team QR.",
          });
          return;
        }

        const result = readScanResult(data);
        if (!result.teamId) {
          setFeedback({
            kind: "error",
            message: "Team QR is valid but team details were not returned.",
          });
          return;
        }

        if (result.hackathonId && result.hackathonId !== hackathonId) {
          setFeedback({
            kind: "error",
            message: "This team QR belongs to a different hackathon.",
          });
          return;
        }

        setFeedback({
          kind: "success",
          message: "Team verified. Opening evaluation form...",
        });
        router.push(`/hackathons/${hackathonId}/judge/evaluate/${result.teamId}`);
      } catch {
        setFeedback({
          kind: "error",
          message: "Unable to process scan right now.",
        });
      } finally {
        setIsSubmitting(false);
      }
    },
    [hackathonId, router],
  );

  return (
    <div className="relative min-h-screen bg-black text-white">
      <Navbar />

      <div className="mx-auto w-full max-w-4xl px-4 py-12 sm:px-6">
        <button
          onClick={() => router.push(`/hackathons/${hackathonId}/judge`)}
          className="mb-8 flex items-center gap-2 text-sm text-white/50 hover:text-white/80"
        >
          <ArrowLeft className="size-4" />
          Back to Judge Panel
        </button>

        <Card className="border-white/10 bg-black/20">
          <CardHeader>
            <CardTitle className="inline-flex items-center gap-2 text-white">
              <ScanLine className="size-5 text-cyan-300" />
              Final Round Evaluation
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {isAuthorizing ? (
              <p className="text-sm text-white/70">Verifying access...</p>
            ) : !canScan ? (
              <>
                <p className="text-sm text-rose-300">{error ?? "Access denied."}</p>
                <Button
                  variant="outline"
                  onClick={() => router.push(`/hackathons/${hackathonId}/judge`)}
                >
                  Return to Judge Panel
                </Button>
              </>
            ) : (
              <>
                <p className="text-sm text-white/60">
                  Scan the TEAM QR only. After verification, you will be redirected
                  directly to the team evaluation page.
                </p>

                <QrScannerCard
                  title="Team QR Scanner"
                  description="Keep the TEAM QR inside the camera frame until detected."
                  onScan={handleScan}
                  isBusy={isSubmitting}
                  busyText="Validating team access..."
                />

                {feedback ? (
                  <p
                    className={
                      feedback.kind === "success"
                        ? "text-sm text-emerald-300"
                        : "text-sm text-rose-300"
                    }
                  >
                    {feedback.message}
                  </p>
                ) : null}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
